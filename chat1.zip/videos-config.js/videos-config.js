// videos-config.js
const EMBED_VIDEOS = [
    {
        id: 1,
        title: "Video 1",
        embed: `<iframe src="https://spankbang.com/33kov/embed/" frameborder="0" scrolling="no" width="100%" height="100%" allowfullscreen></iframe>`,
        source: "spankbang"
    },
    {
        id: 2,
        title: "Video 2",
        embed: `<iframe src="https://spankbang.com/OTRO_ID/embed/" frameborder="0" scrolling="no" width="100%" height="100%" allowfullscreen></iframe>`,
        source: "spankbang"
    }
];

// Función para cargar galería
function loadEmbedGallery() {
    const container = document.getElementById('video-gallery');
    if (!container) return;
    
    container.innerHTML = EMBED_VIDEOS.map(video => `
        <div class="video-card" onclick="openPlayer(${video.id})">
            <div class="video-thumb">
                <span>▶ ${video.title}</span>
            </div>
            <p>${video.source}</p>
        </div>
    `).join('');
}
// Alternativa: Abrir en nueva pestaña si el embed falla
function openPlayer(videoId) {
    const video = EMBED_VIDEOS.find(v => v.id === videoId);
    
    // Intentar embed primero
    const modal = document.createElement('div');
    modal.id = 'video-modal';
    modal.innerHTML = `
        <div class="modal-overlay" onclick="closePlayer()"></div>
        <div class="modal-content">
            <button class="close-btn" onclick="closePlayer()">✕</button>
            <div class="embed-container" id="embed-container">
                ${video.embed}
            </div>
            <div id="fallback-message" style="display:none; text-align:center; padding:20px;">
                <p>El video no puede reproducirse aquí</p>
                <a href="https://spankbang.com${video.embed.match(/src="([^"]+)"/)[1]}" 
                   target="_blank" class="btn">Ver en el sitio original</a>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Verificar si el iframe carga después de 3 segundos
    setTimeout(() => {
        const iframe = document.querySelector('#embed-container iframe');
        try {
            // Si podemos acceder al contentWindow, cargó bien
            const test = iframe.contentWindow.document;
        } catch (e) {
            // Error de CORS = mostrar fallback
            document.getElementById('embed-container').style.display = 'none';
            document.getElementById('fallback-message').style.display = 'block';
        }
    }, 3000);
}
// Abrir reproductor modal
function openPlayer(videoId) {
    const video = EMBED_VIDEOS.find(v => v.id === videoId);
    if (!video) return;
    
    // Crear modal
    const modal = document.createElement('div');
    modal.id = 'video-modal';
    modal.innerHTML = `
        <div class="modal-overlay" onclick="closePlayer()"></div>
        <div class="modal-content">
            <button class="close-btn" onclick="closePlayer()">✕</button>
            <div class="embed-container">
                ${video.embed}
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

function closePlayer() {
    const modal = document.getElementById('video-modal');
    if (modal) modal.remove();
}

// Cargar al iniciar
document.addEventListener('DOMContentLoaded', loadEmbedGallery);